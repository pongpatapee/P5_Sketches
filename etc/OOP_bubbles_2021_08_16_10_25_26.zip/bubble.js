class Bubble{
  constructor(x, y, r){
    this.x = x;
    this.y = y;
    this.r = r;
  }
  
  show(){
    stroke(255);
    strokeWeight(3);
    noFill();
    ellipse(this.x, this.y, this.r, this.r);
  }
  
  move(){
    let mag = 2;
    this.x += random(-mag, mag);
    this.y += random(-mag, mag);
  }
  
  
}
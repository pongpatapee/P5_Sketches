let bubble = [];
let velx;
function setup() {
  createCanvas(400, 400);
  
  for(let i = 0; i < 100; i++){
    let x = random(0, width);
    let y = random(0, height);
    let r = random(20, 80);
    bubble[i] = new Bubble(x, y, r);
  }
}

function draw() {
  background(0);
  
  for(let i = 0; i < bubble.length; i++){
    bubble[i].show();
    bubble[i].move();
  }
  
//   test.show();
//   //test.move();
  
//   test.x += velx;
//   if(test.x < 0 || test.x > width){
//     velx = -velx;
//   }
}


class Player{
  constructor(pos){
    this.pos = pos;
    this.r = 40;
    this.speed = 3;
    this.projectiles = [];
    this.shooting = false;
  }
  
  show(){
       
    for(let i = this.projectiles.length - 1; i >= 0; i--){
      this.projectiles[i].show();
      this.projectiles[i].update();

      if(this.projectiles[i].pos.x > width || this.projectiles[i].pos.x < 0){
        this.projectiles.splice(i,1);
      }
      else if(this.projectiles[i].pos.y > height || this.projectiles[i].pos.y < 0){
        this.projectiles.splice(i,1);
      }
    }
    stroke(0);
    fill(255);
    ellipse(this.pos.x, this.pos.y, this.r, this.r);
  }
  
  move(){
    if(keyIsDown(87)){
      this.pos.y -= this.speed;
    }
    if(keyIsDown(83)){
      this.pos.y += this.speed;
    }
    if(keyIsDown(65)){
      this.pos.x -= this.speed;
    }
    if(keyIsDown(68)){
      this.pos.x += this.speed;
    }
  }
  
  shoot(vel){
    let projectile = new Projectile(this.pos.copy(), vel);
    this.projectiles.push(projectile);
  }

}
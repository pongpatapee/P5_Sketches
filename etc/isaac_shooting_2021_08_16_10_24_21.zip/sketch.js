let player;
let projectiles = [];
function setup() {
  createCanvas(400, 400);
  player = new Player(createVector(width/2, height/2));
  
}

function draw() {
  background(220);
  
  print(player.projectiles.length);
  
  let rate = 10;
  
  //reducing firerate with framerate rn, fix later
  if(keyIsDown(UP_ARROW)){
    let vel = createVector(0, -1);
    
    if(frameCount % rate == 0)
      player.shoot(vel);
  }
  else if(keyIsDown(DOWN_ARROW)){
    let vel = createVector(0, 1);
    if(frameCount % rate == 0)
      player.shoot(vel);
  }
  else if(keyIsDown(LEFT_ARROW)){
    let vel = createVector(-1, 0);
    if(frameCount % rate == 0)
      player.shoot(vel);
  }
  else if(keyIsDown(RIGHT_ARROW)){
    let vel = createVector(1, 0);
    if(frameCount % rate == 0)
      player.shoot(vel);
  }
  
  player.show();
  player.move();
  fill(0);
  

}


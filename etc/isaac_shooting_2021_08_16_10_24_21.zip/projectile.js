class Projectile{
  constructor(pos, vel){
    this.pos = pos;
    this.vel = vel;
    this.speed = 5;
    this.r = 10;
  }
  
  show(){
    stroke(0);
    fill(0);
    ellipse(this.pos.x, this.pos.y, this.r, this.r);
  }
  
  update(){
    this.vel.setMag(this.speed);
    this.pos.add(this.vel);
  }
}
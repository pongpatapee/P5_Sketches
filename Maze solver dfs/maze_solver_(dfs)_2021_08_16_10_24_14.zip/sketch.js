let dim = 8;
let size;
// let grid = [];
let grid = [['#','#','#','#','#','#','O', '#'],
		['#',' ',' ','#',' ','#',' ', '#'],
		['#',' ',' ',' ',' ','#',' ', '#'],
		['#',' ','#','#',' ','#',' ', '#'],
		['#',' ','#',' ',' ',' ',' ', '#'],
		['#',' ','#','#','#','#',' ', '#'],
		['#',' ',' ',' ',' ','#',' ', '#'],
		['#','#','#','X','#','#','#', '#']]
let state;
let div;
let clicking = false;
let path = [];
let path_moves = [];
let moves = ['L', 'R', 'U', 'D'];
let pos;
function setup() {
  createCanvas(600, 600);
  
  // for(let i = 0; i < dim; i++){
  //   grid = new Array(10);
  // }
  // for(let j = 0; j < dim; j++){
  //   grid[j] = new Array(10);
  // }
  
  

  //clear_grid();
  pos = createVector();
  state = '#';
  size = width/dim;
  div = createDiv('').size(100, 100);
  print(grid)
}


function draw() {
  background(220);
  draw_grid();
  
  
  div.html('Current state: '+ state);
  if(clicking){
    let y = floor(mouseY/size);
    let x = floor(mouseX/size);
    
    grid[x][y] = state;
    //write logic so that there can only be one entrance and exit
  }
}

function mousePressed(){
  clicking = true
}

function mouseReleased(){
  clicking = false;
}

function keyPressed(){
  if(key == 'w'){
    state = '#';
  }
  else if(key == 'o'){
    state = 'O';
  }
  else if(key == 'x'){
    state = 'X';
  } else if (key == 'e'){
    state = ' ';
  } else if(key == 's'){
    pos = get_start_pos();
    dfs(pos, path, path_moves, false);
    console.log('Solved');
  } else if(key == ' '){
    clear_grid();
    console.log('Clear Grid');
  }
  console.log('Changed state to: ' + state);
}
function clear_grid(){
  for(let i = 0; i < dim; i++){
    for(let j = 0; j < dim; j++){
      if(i == 0 || j == 0 || i == dim - 1 || j == dim -1){
        grid[i][j] = '#';
      } else {
        grid[i][j] = ' ';
      }
      
    }
  }
}

function draw_grid(){
  //using global grid
  push();
  stroke(0);
  strokeWeight(2);
  for(let i = 0; i < dim; i++){
    for(let j = 0; j < dim; j++){
      if(grid[i][j] == ' '){
        fill(255);
      }
      else if(grid[i][j] == '#'){
        fill(0);
      }
      else if(grid[i][j] == 'O'){
        fill(0, 0, 255);
      }
      else if(grid[i][j] == 'X'){
        fill(255, 0, 0);
      }
      else if(grid[i][j] == '+'){
        fill(0, 255, 255);
      }
      rect(i * size, j * size, size, size);
      
    }
  }
  pop();
}




